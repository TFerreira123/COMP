#include <unistd.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#define MAX 100
#include "struct.h"


node* newNode(char *type, char* value);
node *addFil1(node *parent, node *fil);
node * addFil2(node *parent, node *value1, node *value2);
node * addFil3(node *parent, node *value1, node *value2,node *value3);
node* addIrmao(node *head, node *irmao);
int conta_irm(node* no);
node *cicloWhile(node *cond, node *content);
void getAnotation(node* node, char* FuncId);
void imprimeAST(node * root,int nivel);
void apagaAST(node *root);
