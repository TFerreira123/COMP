#ifndef SYMBOL_TABLE_H
#define SYMBOL_TABLE_H

//typedef enum {Bool, Double,  Int, StringArray,  Void,  undef} basic_type;
#include "struct.h"


typedef struct _t1{
	 //nome do elemento
	char * nome;
	//lista de parametros
	char * paramTypes;
	 //tipo do elemento
	char * type;
	//aqui os param da funcao caso seja var globlais 
	char * params;
	struct _t1 *next_element;
} table_element;

typedef struct _t2{
	//tipo do return
	char * type;
	//ID da funcao
	char * id;
	//lista do tipo dos parametros
	char * paramTypes;
	table_element *element;
	struct _t2 *next_table;
} table;

table_element * createElement(char *nome, char* paramTypes, char *type, char *isparam);
table * createTable(char *type, char * id, char *paramTypes, table_element *te);
table * create_method_table(table * t, node * n);

char* lower(char *type);
int var_declared(table * tab, char *funcId,char *varId);
int method_declared(table * tab, char *funcId, char * params);

void make_tables(node * tree, table * tabela);
void fill_method_table(table * tab, node * n);
void insert_element(table * tab, table_element * ele);


void printa_tabelas(table * t);

#endif
