#ifndef STRUCT_H
#define STRUCT_H


typedef struct node
{
    char *token;
    char *value;
    char *anotation;
    struct node *next;
    struct node *fil;
} node;


#endif 