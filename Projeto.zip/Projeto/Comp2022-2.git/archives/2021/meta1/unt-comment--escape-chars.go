package main;

func factorial(n int) int {
    if n == 0 {
        return 1;
    };
    return n * factorial(n-1);
};

func main() {
    var argument int$;
    var string s = "He\allo";
    var string s2 = "Hello
    \" my friend \"";

    var string s3 = "Hello\n world!"

    // lmao

    // \n \t \r \" "

    /* string

    */

    argument,_ = strconv.Atoi(os.Args[1]);
    fmt.Println(factorial(argument));
    
    var cons oct  = 0x12a349;
    var cons oct3 = 01234;
    var cons oct2 = 012a349;

    /*
};
