int main(void){
	char a='H';
	char b = 'e';
	putchar(a);
   	putchar(b);
	putchar('l');
	putchar('l');
	putchar('o');
	char c =' ';
	char d ='W';
	putchar(c);
	putchar(d);
	char e ='o';
	putchar(e);
	putchar('r');
	putchar('l');
	putchar('d');
	char f='\n';
	putchar(f);
}