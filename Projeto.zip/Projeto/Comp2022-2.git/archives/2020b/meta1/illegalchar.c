<>qwertyuiopásdfghjklç~\zxcvbnm,.-______j!"#$%&/(==?*´\~@
|| |char
elsewhileifshort    inT intdoublereturnvoid^&&<=>=
{    [#}!=++--
      int double  return  void    short   while   else
      \tolelele
/*lll
kkk*/?
wtf//gefggt
#
