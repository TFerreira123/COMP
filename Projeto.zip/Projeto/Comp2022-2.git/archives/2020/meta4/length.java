class varsAndMethods {
	//Introduce '1' and '3' as parameters
    public static void main(String[] args) {
		System.out.print(args.length);
		System.out.print("\n");
    }
}