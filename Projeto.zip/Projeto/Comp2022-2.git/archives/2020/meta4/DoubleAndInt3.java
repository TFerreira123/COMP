class Main {
    public static double d;
	public static double test(double n){
		return n;
	}


    public static void main(String[] args) {
        System.out.print(test(4));
        System.out.print("\n");
        d=2;
        System.out.print(d);
		System.out.print("\n");
    }
}