//compilar com flag -l
loop: cmp 051:, 0xcd10xba
:ab 0x123 ret

public this ++ protected

System.out.print("esta string da erro)
"esta tbm \h

//este cometario e valido

/**
comentario nao acaba