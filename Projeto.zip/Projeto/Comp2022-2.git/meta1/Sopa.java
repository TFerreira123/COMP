class Sopa{
	public static void main(String[] args) {
		"Duas" +
		"linhas de string"
		String nome = "val\fid\a?";
		System.out.print(nome);
		Ststem.out.print("erro);
		"e\ndwqd\"wqdwq		\*\*\*|\*|\*|*|*|+\*

		*/comentario que nao comeca
		*
		++
		--
		1210
		nem acaba*\
		}
}