"Esta e uma string valida"
"esta nao
class Main {
	"esta tambem nao
	public static int soma(int n) {
	?# /*caracteres ilegais*/
	/*algumas mudancas de linha com \r*/"Mais uma string incompleta
/*Comentario sem fim