class teste{
    public static void xd(String[] args){
        int d;
        System.out.print(args);
        System.out.print(d.length);
        System.out.print(args.length);
        System.out.print(Integer.parseInt(args[2.0]));
        System.out.print(Integer.parseInt(args[2]));
        System.out.print(Integer.parseInt(args[e]));
        return args;
        return Integer.parseInt(args[2.0]);
        return xd(args);
        return d;
        return 2.0;
    }

}