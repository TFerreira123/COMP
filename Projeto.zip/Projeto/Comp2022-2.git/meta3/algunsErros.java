class Alguns_Erros {
    public static int main1(){
        return;
    }
    public static double main2(){
        int a;
        return a;
    }
    public static int  main3(){
        double a;
        return a;
    }
    public static int cenas(String[] args) {
        cenas(args);
        int x;
        x = x.length;
        x = Integer.parseInt(args[0]);
        x = Integer.parseInt(x[0]);
        if(2+true*true){
    
        }
        int a;          
        a = b + true;
        a = 1 + b;      
        a = b + 1;      
        a = b * c;      

        double xd;
        xd = a;
    }

    public static void main(String[] args){
        int i,i2 ;
        double d;
        boolean b;
        i = d = b;
        i = 123123122121;
        int x;
        i = d = b;
        return;
        factorial(i,i,i);
    }

    public static void ola(String[] args) {
        int a;
        boolean b;
        double c;
        return a;
        return b;
        return c;
        return args;
        return ola(args);
    }

}