class xd {
  public static void main() {
  	int a, b, c;

    alo = -a.length;
    ola = (b) + (c) + (d+2)*25;
    call((x(x(x(x(x(x(x(x(x(x(x(x(x(x(x(x(x(x(x(x(x(x(x(x(x(x(x(x(x(x(x(x(x(x(x(x(x(x(x(x(x(x(x()))))))))))))))))))))))))))))))))))))))))))));
    while(a+b+c+d+x+x+x+x+x);
    if(t==3+3){
    	a = 555*1000 || 4E2 && 0 + a;
    }
    while(x=3);
    call2((x(x(x(x(x(x(x(x(x(x(x(x(x(x(x(x(x(x(x(x(x(x(x(x(x(x(x(x(x(x(x(x(x(x(x(x(x(x(x(x(x(x(x()))))))))))))))))))))))))))))))))))))))))))));
    while((x(x(x(x(x(x(x(x(x(x(x(x(x(x())))))))))))))));
    i= 2+2+2+2+2+2+2+2+2;
    {
        a=1;;
        b=2;
    }
    if(x){
        if(x){
            if(x){
                if(x){
                    if(x){
                        if(x){
                            if(x){
                                if(x){
                                    if(x){
                                        if(x){
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
  	x = true || false; 
  	System.out.print(-xD*-$t);
  }
}