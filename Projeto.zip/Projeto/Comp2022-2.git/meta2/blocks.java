class assign_error {
    public static void main(String[] args) {
        { i = 1;
            j = 1.0;
            k = true;}
    }
  }
  


