class Error {
    public static double argument;;;;;;
    public static int error(float n) {
    	
    }
    ;;;;;;;;
    public static void no_errorrrrrrrr(String[] args) {
    	no_error(a = (b = (1+2)));	
    };
}