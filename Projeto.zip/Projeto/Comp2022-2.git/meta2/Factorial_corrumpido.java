class Factorial {
    public static int factorial(in2t n) {
        if (n == 500
            return 0;
        return n * factorial(n-1);
    }

    public static void main(String[4] args) {
        int args[1];
        argument = .parseInt(300);
        System.out.print(factorial(argument));CHUJ
        XD
        Integer = 3;
    }
}
