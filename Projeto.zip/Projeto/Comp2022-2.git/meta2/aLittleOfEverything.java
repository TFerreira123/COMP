      
	     
class newClass{
	public static int i;
	public static boolean b;
	public static int main(String[] args) {
		boolean b;
		int i1;
		if(args) {
			if(Integer.parseInt(args[0]) == 1){
				System.out.print("The first argument is one");
			} else {
				System.out.print("The value is something!");
			}
		}
		if(b) if(i1 == 10){;} else {System.out.print("Within the second else"); }
		int a,b,j,k;		
		{{a = 3; {c = 4; {j = 3 + 1;}}}}

		while(true) {
			while(false) {
				k = 3 + 10 * 3;
			}
		}
		test();
		return 0;
	}
	public static int pI;
	public static void a (int a, int b) {
		System.out.print("Arguments: a -> ");
		System.out.print(a);
		System.out.print("b is: ");
		System.out.print(b);
	}
	public static void test() {
		a(2,3);
		"This is an unterminated string	
		int finalI;
		finalI = 2 + 3;
	}

	public static int sum(int k,int j) {
		return k + j;
	}
}
/*The file ends with an unterminated comment
