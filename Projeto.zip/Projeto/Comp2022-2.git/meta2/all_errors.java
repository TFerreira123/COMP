// Compilar com a flag -e2

class assign_error {
  public static void main(String[] args) {
    f(i = j = a&&b = l);
    ola(skrttt, tiago bacano, to_incrivel);
    Integer.parseInt(int void());
    return (20 a comp);
  }
  public static int void mekie();
}

