class Stats{
    public static double stats(int a, double b, boolean c, int a) {
        if (!a != 555);
        if (c < 666){;}else{
            if(!b > 1){a = 22;{if(!a != 0){b = 3;{}}else{;}}}else;
            return 0;
        }
        return c * statsl(args);
    }

}
