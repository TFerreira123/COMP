#include "symbol_table.h"
#include<stdlib.h>
#include<string.h>
#include<stdio.h>
#include "struct.h"
extern int n_table; 

//cria elemento
table_element * createElement(char *nome, char* paramTypes, char *type, char *isparam){
    table_element * te= (table_element *)malloc(sizeof(table_element));
    te->nome=nome;
    te->paramTypes = strdup(paramTypes);
    te->type=strdup(type);
	te->params = isparam;
    te->next_element=NULL;
    return te;
}

//cria tabela
table * createTable(char *type, char * id, char *paramTypes, table_element *te){
    table * method_table = (table *)malloc(sizeof(table));
    
    method_table->type=type;
    method_table->id=id;
    method_table->paramTypes = strdup(paramTypes);
    method_table->element = te;
    method_table->next_table = NULL;

    return method_table;
}


char* lower(char *type){

    if(strcmp(type,"StringArray") == 0){
        type = "String[]";
    }
    else if(strcmp(type,"Double") == 0){
        type = "double";
    }
	else if(strcmp(type,"Int") == 0){
        type = "int";
    }
    else if(strcmp(type,"Void") == 0){
        type = "void";
    }
    else if(strcmp(type,"Bool") == 0){
        type = "boolean";
    }
    return type;
}


int var_declared(table * tab, char *methodId, char *varId) {

    //Verifica se a variavel foi declarada 
    //1 se declarada, 0 nao declarada

    table *aux = tab;
    table_element *aux2 = aux->element;

    //verifica se a variavel esta declarada na tabela global
    while(aux2 != NULL){
        if (strcmp(aux2->nome, varId) == 0){
            return 1;
        }
        aux2 = aux2->next_element;
    }
    aux = aux->next_table;


    if (methodId != NULL){
        //verifica se a variavel esta declarada na tabela local
        while (aux != NULL) {
            if(strcmp(aux->id, methodId)==0){

                aux2 = aux->element;

                while (aux2 != NULL) {
                    if(strcmp(aux2->nome, varId)==0){
                        return 1;
                    }
                    aux2 = aux2->next_element;
                }   
            }
            aux = aux->next_table;
        }
    }

    return 0;
}


int method_declared(table * tab, char *methodId, char * params){
	//verifica se a funcao foi declarada
    //1 se delarada, 0 nao declarada

    table *aux = tab;
	
	while(aux !=NULL){
		if (strcmp(aux->id,methodId) == 0 && strcmp(aux->paramTypes, params) == 0){
			return 1;
		}

		aux = aux->next_table;
	}
	return 0;
}


void printa_tabelas(table *t){

	if(t==NULL){
		return;
	}

    if (n_table == 0){
        printf("===== Class %s Symbol Table =====\n", t->id);
        n_table += 1;
    }else{
        printf("===== Method %s%s Symbol Table =====\n", t->id, t->paramTypes);
    }
    

    table_element * aux = t->element;
    while(aux != NULL){
        //if (strcmp(aux->paramTypes,"")==0){
            printf("%s\t%s\t%s%s\n", aux->nome, aux->paramTypes, aux->type, aux->params);
        //}
        /*else{
            printf("%s\t%s\t%s%s\n", aux->nome, aux->paramTypes, aux->type, aux->params);
        }*/
        
        aux = aux->next_element;
    }

    printf("\n");

    printa_tabelas(t->next_table);
}


void make_tables(node * tree, table * tabela){

    if (tree == NULL){
        return; 
    }
    if (strcmp(tree->token, "MethodDecl")==0){

        node *params = tree->fil->fil->next->next->fil;
        // estamos no methodDecl - MethodHeader(fil,next,next) - methodParams(fil) - formalPrams(temos de percorrer os irmaos)
        char strParams[250] = "(";

        while(params != NULL){
            strcat(strParams,lower(params->fil->token));
                if(params->next!=NULL){
                    strcat(strParams,",");
                }
            params=params->next;
        }
        strcat(strParams, ")");

        if (!method_declared(tabela, tree->fil->fil->next->value, strParams)){

            table * method_table = create_method_table(tabela, tree);

            insert_element(tabela, createElement(method_table->id, method_table->paramTypes, method_table->type, ""));
            
            insert_element(method_table, createElement("return", "", lower(tree->fil->fil->token), ""));

            
            //precorre os parametros
            node * aux_params = tree->fil->fil->next->next->fil;
            
            // enquanto o no "MethodParams" tiver filhos, precorre-os todos e insere na tabela
            while(aux_params != NULL){
                insert_element(method_table, createElement(aux_params->fil->next->value, "", lower(aux_params->fil->token), "\tparam"));
                aux_params = aux_params->next;
            }

            // percorrer os descendentes do no "MethodBody" e inserir variaveis na tabela
            fill_method_table(method_table, tree->fil->next->fil);
        }
    }
    
    if (strcmp(tree->token, "VarDecl") == 0 || strcmp(tree->token, "FieldDecl")==0){
        if (!var_declared(tabela, "", tree->fil->next->value)){
            insert_element(tabela, createElement(tree->fil->next->value, "", lower(tree->fil->token), ""));
        }
    }

    make_tables(tree->next, tabela);    
    return;
}


//cria a tabela do método e adiciona à tabela global
table * create_method_table(table * t, node * n){


    table_element *aux = t->element;
    node *params = n->fil->fil->next->next->fil;
    // estamos no methodDecl - MethodHeader(fil,next,next) - methodParams(fil) - formalPrams(temos de percorrer os irmaos)
    char strParams[250] = "(";

    while(params != NULL){
        strcat(strParams,lower(params->fil->token));
            if(params->next!=NULL){
                strcat(strParams,",");
            }
        params=params->next;
    } 

    strcat(strParams, ")");

    node *nAux = n;
    table *tab = t;
    table* last_table = NULL;
    while(tab !=NULL){
        last_table = tab;
        tab = tab->next_table;
    }
    tab = createTable(lower(nAux->fil->fil->token), nAux->fil->fil->next->value, strParams, NULL);
    last_table->next_table = tab;

    return tab;
}



void fill_method_table(table * tab, node * n){

    if (n == NULL){
        return;
    }

    if (strcmp(n->token, "VarDecl") == 0){
        if (!var_declared(tab, tab->id, n->fil->next->value)){
            insert_element(tab, createElement(n->fil->next->value, "", lower(n->fil->token), ""));
        }

    }

    fill_method_table(tab, n->fil);
    fill_method_table(tab, n->next);
    return;
}


void insert_element(table * tab, table_element * elem){

    if (tab->element == NULL){
        tab->element = elem;
        return;
    }

    table_element * last = tab->element;
    table_element * current = last->next_element;
 
    while(current != NULL){
        last = current;
        current = current->next_element;
    }

    last->next_element = elem;
    return;
}




