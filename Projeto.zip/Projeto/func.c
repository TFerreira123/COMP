#include "struct.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>


node *newNode(char *token, char* value,char*anot){
    node *newnode = (node *)malloc(sizeof(node));

    newnode->token = token;
    newnode->value = value;
    newnode->anotation = anot;
    newnode->next = NULL;
    newnode->fil = NULL;

    return newnode;
}
node *addFil1(node *parent, node *fil)
{
    parent->fil = fil;
    return parent;
}

node * addFil2(node *parent, node *value1, node *value2){
    parent->fil = value1;

    if (value1 != NULL)
    {
        value1->next = value2;
    }

    return parent;
}

node * addFil3(node *parent, node *value1, node *value2,node *value3){
    parent->fil = value1;

    if (value1 != NULL)
    {
        value1->next = value2;
        if(value2 != NULL){
            value2->next = value3;
        }
    }

    return parent;
}

node* addIrmao(node *head, node *irmao){
     node *ptr = head;

    if (head == NULL)
    {
        return irmao;
    }

    while (ptr->next != NULL)
    {
        ptr = ptr->next;
    }

    ptr->next = irmao;

    return head;
}

int conta_irm(node* no){
    int count = 0;
    node * aux = no;

    while(aux != NULL){
        count++;
        aux = aux->next;
    }
    
    return count;
}


node *cicloWhile(node *cond, node *content){

   
    node *aux = NULL;
    node *auxBlock = NULL;
    if (conta_irm(content) == 1){
        
        aux = addIrmao(cond,content);
        return addFil1(newNode("While",NULL,""),aux);
    }
    else{
        auxBlock = addIrmao(cond,newNode("Block",NULL,""));
        aux = addIrmao(auxBlock,content);
        return addFil1(newNode("While",NULL,""),aux);
    }
    
}

void getAnotation(node* node){
    //percorrer os nos ate chegar aos restantes 

    //Bool
    if(strcmp(node->token,"Gt")==0 || strcmp(node->token,"Ge")==0  || strcmp(node->token,"Eq")==0 || strcmp(node->token,"Ne")==0 ||strcmp(node->token,"Not")==0 ||
    strcmp(node->token,"And")==0 || strcmp(node->token,"Or")==0 || strcmp(node->token,"Le")==0 || strcmp(node->token,"Lt")==0 || strcmp(node->token,"Gt")==0){
       
        node->anotation=strdup("bool");
     
    }
     //Intlit
    if(strcmp(node->token,"IntLit")==0){
        node->anotation=strdup("int");
    }
    //Reallit
    if(strcmp(node->token,"RealLit")==0){

        node->anotation=strdup("double");
    }
     //Assign
    if(strcmp(node->token,"Assign")==0){
        //vamos buscar o token do id e verificar se não é stringArray
       char *var1 = node->fil->token;
       char *var2 = node->fil->next->token;
       if (strcmp(var1,var2)!=0){
            printf("O operador assign não pode ser feito por as variaveis não serem do mesmo tipo!");
       }
       else{
            getAnotation(node->fil,FuncId);
       }
    }
    //Call....
    if(strcmp(node->token,"Call")==0){
        //enquanto tiver irmaos
        while(node->fil != NULL){


            node->fil = node->fil->next;
        }
    }

    //Ids.....


    if(strcmp(node->token, "Plus")==0 || strcmp(node->token,"ParseArgs")==0 || strcmp(node->token,"Mul")==0 || strcmp(node->token,"Add")==0 || strcmp(node->token,"Sub")==0 || strcmp(node->token,"Mod")==0 || strcmp(node->token,"Minus")==0 || strcmp(node->token,"Div")==0){
        struct node * aux=node;
        
       
        while(aux!=NULL){
            if(strcmp(aux->token,"Id")==0){
                //falta conseguir o token
                node->anotation=strdup();
                break;
               
            }
            if(strcmp(aux->token,"RealLit")==0){
                char * anot = "double";
                node->anotation=strdup(anot);
                break;
            }
            if(strcmp(aux->token,"IntLit")==0){
                char * anot = "int";
                node->anotation=strdup(anot);
                break;

            }

            aux=aux->fil;

        }
        
    }
    
}


void apagaAST(node * root){
    if (root == NULL){
        return;
    }
    apagaAST(root->fil);
    apagaAST(root->next);
    free(root);
    return;
}


void imprimeAST(node * root, int nivel){
    if (root == NULL){
        return;
    }

    for (int i = 0; i < nivel; i++){
        printf("..");
    }
    
    if (root->value == NULL){
        printf("%s\n", root->token);
    }
    else{
        printf("%s(%s)\n", root->token, root->value);
    }
    

    imprimeAST(root->fil, nivel + 1);
    imprimeAST(root->next, nivel);
}